<!DOCTYPE html>

<html dir="{{ in_array(Auth::user()->language, ['ar', 'il', 'fa', 'ar_AR', 'he_IL']) ? 'rtl' : 'ltr' }}">

<head>

    <!-- Global site tag (gtag.js) - Google Analytics -->
	@if (config('app.env') == 'production')
		<script src="{{ asset('js/prod.js') }}"></script>
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-NR92JDYG1J"></script>
		<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', 'G-NR92JDYG1J');
		</script>
	@else
		<script> function gtag () { console.warn('gtag only available in production') } </script>
	@endif

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">

	<title>@yield('title') | Builderall Booking</title>

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="g-recaptcha-sitekey" content="{{ config('services.google_recaptcha.sitekey') }}">
    <meta name="base-url" content="{{ url('/') }}">
    <meta name="user-lang" content="{{ Auth::user()->language }}">

    <link href="{{ mix('css/app.css') }}" rel="stylesheet">
    <link href="{{ mix('css/custom.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:400,500,600,700,800,900&display=swap">
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="{{ asset('images/images/meta/favicon.png') }}">
    <link rel="manifest" href="/manifest?lang={{ Auth::user()->language }}" />
    <noscript>To run this application, JavaScript is required to be enabled.</noscript>
    <meta name="theme-color" content="#0080fc" />
    <link rel="apple-touch-icon" href="{{asset('images/pwa/apple-touch-icon-iphone-60x60.png')}}">
    <link rel="apple-touch-icon" sizes="60x60" href="{{asset('images/pwa/apple-touch-icon-ipad-76x76.png')}}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{asset('images/pwa/apple-touch-icon-iphone-retina-120x120.png')}}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{asset('images/pwa/apple-touch-icon-ipad-retina-152x152.png')}}">

</head>

<body>

    @if ($fullpage ?? '')

    <div id="app">
        @yield('content')
    </div>

    @else

    <div id="app">

        <vue-snotify></vue-snotify>

        <the-navbar :usuario="{{ Auth::user()->toJson() }}"></the-navbar>

        <div class="container-fixed">

            <the-sidebar
                current="{{ Route::currentRouteName() }}"
                :pending="{{ Auth::user()->getScheduleCountByStatus() }}">
            </the-sidebar>

            <the-notification-center
                owner="{{ md5(Auth::user()->email) }}">
            </the-notification-center>

            <the-flash-messenger
                message="{{ session('message') }}">
            </the-flash-messenger>

            <main id="main">

            <b-container>
                <div class="flex-fill px-sm-2 py-4 py-sm-5">
                    @yield('content')
                </div>
            </b-container>

            </main>

        </div>

    </div>

    @endif

</body>

<script src="{{ mix('js/app.js') }}"></script>

@if (config('app.env') != 'local')
<script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js');
    });
}
</script>
@endif

<!-- Hotjar Tracking Code for office.builderall.com -->
@if (config('app.env') == 'production')
	<script>
	(function(h,o,t,j,a,r){
		h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
		h._hjSettings={hjid:1035500,hjsv:6};
		a=o.getElementsByTagName('head')[0];
		r=o.createElement('script');r.async=1;
		r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
		a.appendChild(r);
	})(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
	</script>
@endif

</html>
